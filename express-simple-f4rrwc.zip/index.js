const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');

const port = 3010;

const app = express();

app.use(bodyParser.json());

const store = ['Welcome to the Board! Send in your worst dad jokes.'];

app.get('/api/dad', (req, res) => {
  res.status(200).json({ jokes: store });
});

app.post('/api/dad', (req, res) => {
  const { newJoke } = req.body;
  store.push(newJoke);
  res.status(200).send();
});

app.get('/', (req, res) => {
  res.sendFile(path.resolve('pages/index.html'));
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});
